ANUSHKA BIRTHDAY LOVE APP

Open index.html in a browser.
Tap "Open Your Surprise" to show the message/photos and start the audio.

The app is self-contained: photos and audio are embedded in index.html.
For a QR code that works on another phone, host this folder/app publicly first.
